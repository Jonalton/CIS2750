<HTML><BODY>
    <FORM method='post' action='index.php' enctype='multipart/form-data'>
        Input File Number: <input type="text" name="filenum">
        <input type="submit" value="Submit">
    </FORM>
</BODY></HTML>