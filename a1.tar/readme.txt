CIS2750 A2
Jonalton Jude Hamilton
1045218

Valgrind memory leaks come from Py_Initialize() and Py_Finalize, not sure how to solve leaks
Compiler Warnings for struct *timespec, unable to solve the warning
All functions of the assignemnt work as specified
to run:
    1. make
    2. ./a2 <filename>