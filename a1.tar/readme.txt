Jonalton Jude Hamilton
1045218
Everything should be working properly
to run:
    1. make
    2. ./a1 <filename>